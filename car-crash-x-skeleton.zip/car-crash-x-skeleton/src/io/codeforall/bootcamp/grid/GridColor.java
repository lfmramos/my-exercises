package io.codeforall.bootcamp.grid;

/**
 * The available grid colors
 */
public enum GridColor {

    RED,
    GREEN,
    BLUE,
    MAGENTA,
    NOCOLOR

}
